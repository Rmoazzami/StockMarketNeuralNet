import pandas as pd
import pickle

companies = pd.read_csv("sandp500.csv")
companyTickers = set(companies["Symbol"])
companyNames = set(companies["Security"])

print companyTickers
print companyNames

with open('tickers.pkl', 'wb') as fp:
    pickle.dump(companyTickers, fp)

with open('names.pkl', 'wb') as fp:
    pickle.dump(companyNames, fp)
