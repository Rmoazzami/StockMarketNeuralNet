import pandas as pd
import pickle
import os.path

df = pd.read_pickle('articleAnalysis1.pkl')

for row in df.values:
    ticker = row[1]
    datetime = row[0]
    date = datetime[0:4] + datetime[5:7] + datetime[8:10]
    filename = ticker + ".pkl"
    if os.path.exists(filename):
        file = pickle.load(filename)
        day = file[date]
        hour = datetime[11:13]
        minute = datetime[14:16]
        min = (9 * 60) + 30
        article_time = int(hour) * 60 + int(minute)
        max = (15 * 60) + 59
        index = 0
        if article_time <= min:
            index = 0
        elif article_time >= max:
            index = -1
        else:
            index = article_time - min
        article_minute = day[index]
        end_minute = day[-1]
        print(article_minute)
        print(end_minute)

