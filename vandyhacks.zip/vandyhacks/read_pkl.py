import pickle
import sys

if __name__ == "__main__":
    filename = sys.argv[1]
    with open (filename, 'rb') as fp:                                     
        all_articles = pickle.load(fp)  
        print(all_articles)

